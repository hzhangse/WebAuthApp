/*
 * Copyright (c) 1998-2012 Caucho Technology -- all rights reserved
 *
 * This file is part of Resin(R) Open Source
 *
 * Each copy or derived work must preserve the copyright notice and this
 * notice unmodified.
 *
 * Resin Open Source is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Resin Open Source is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, or any warranty
 * of NON-INFRINGEMENT.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Resin Open Source; if not, write to the
 *
 *   Free Software Foundation, Inc.
 *   59 Temple Place, Suite 330
 *   Boston, MA 02111-1307  USA
 *
 * @author Scott Ferguson
 */

package com.caucho.jcr.svn;

import com.caucho.server.connection.Connection;
import com.caucho.server.port.ServerRequest;
import com.caucho.util.Alarm;
import com.caucho.util.L10N;
import com.caucho.util.QDate;
import com.caucho.vfs.ReadStream;
import com.caucho.vfs.WriteStream;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Single subversion request.
 */
public class SubversionRequest implements ServerRequest {
  private static final L10N L = new L10N(SubversionRequest.class);
  private static final Logger log =
    Logger.getLogger(SubversionRequest.class.getName());

  private Connection _conn;
  private ClassLoader _loader;

  private Repository _repository;

  private ReadStream _is;
  private WriteStream _os;

  private SubversionInput _in;

  private String _url;
  private String _uuid;
  private String _author = "ferg";

  private Session _session;
  private String _rootPath;
  
  SubversionRequest(Connection conn,
		    ClassLoader loader,
		    Repository repository)
  {
    _conn = conn;
    _loader = loader;
    _repository = repository;
  }
  
  /**
   * Initialize the connection.  At this point, the current thread is the
   * connection thread.
   */
  public void init()
  {
  }

  public boolean isWaitForRead()
  {
    return false;
  }
  
  /**
   * Handles a new connection.  The controlling TcpServer may call
   * handleConnection again after the connection completes, so 
   * the implementation must initialize any variables for each connection.
   *
   * @param conn Information about the connection, including buffered
   * read and write streams.
   */
  public boolean handleRequest() throws IOException
  {
    Thread thread = Thread.currentThread();
    
    ClassLoader oldLoader = thread.getContextClassLoader();

    try {
      thread.setContextClassLoader(_loader);

      _os = _conn.getWriteStream();
      _is = _conn.getReadStream();

      _session = null;
      _in = new SubversionInput(_is);

      _url = null;

      print("( success ( 1 2 ( ANONYMOUS ) ( edit-pipeline ) ) )");

      if (! readHello())
	return false;

      println("( success ( ( ANONYMOUS ) 0: ) )");

      Object auth = _in.readSexp();

      println("( success ( ) )");

      _uuid = "fde600c4-d415-0410-b624-f0eefa76416f";

      println("( success ( " + enc(_uuid) + " " + enc(_url) + " ) )");

      while (true) {
	_in.skipWhitespace();

	int ch = _in.read();

	if (ch < 0)
	  return false;
	else if (ch != '(')
	  throw error(L.l("expected '(' at '{0}' (0x{1})",
			  ch, Integer.toHexString(ch)));

	String cmd = _in.readLiteral();

	if ("get-latest-rev".equals(cmd)) {
	  doGetLatestRev();
	}
	else if ("check-path".equals(cmd)) {
	  doCheckPath();
	}
	else if ("get-dir".equals(cmd)) {
	  doGetDir();
	}
	else if ("update".equals(cmd)) {
	  doUpdate();
	}
	else if ("set-path".equals(cmd)) {
	  doSetPath();
	}
	else if ("finish-report".equals(cmd)) {
	  doFinishReport();
	}
	else if ("failure".equals(cmd)) {
	  doFailure();
	}
	else if ("success".equals(cmd)) {
	  doSuccess();
	}
	else {
	  log.fine(L.l("'{0}' unknown subversion command", cmd));

	  return false;
	}
      }
    } catch (IOException e) {
      e.printStackTrace();
      
      throw e;
    } finally {
      thread.setContextClassLoader(oldLoader);
    }
  }

  /**
   * Reads the client's hello.
   */
  private boolean readHello()
    throws IOException
  {
    if (! _in.skipWhitespace())
      return false;
    
    _in.expect('(');

    String id = _in.readLiteral();

    Object cap = _in.readSexp();

    _url = _in.readString();

    _in.expect(')');

    try {
      _session = _repository.login();

      int i = _url.indexOf("://");
      String base = _url;
      if (i >= 0) {
	i = _url.indexOf('/', i + 3);

	if (i > 0)
	  _rootPath = _url.substring(i);
	else
	  _rootPath = "";
      }
      else
	_rootPath = "";
    } catch (Exception e) {
      throw new RuntimeException(e);
    }

    return true;
  }

  /**
   * Handle get-latest-rev
   */
  private void doGetLatestRev()
    throws IOException
  {
    skipSexp();

    _in.expect(')');

    int rev = 1;

    println("( success ( ( ) 0: ) )");
    println("( success ( " + rev + " ) )");
  }

  /**
   * Handle check-path
   */
  private void doCheckPath()
    throws IOException
  {
    _in.expect('(');

    String path = _in.readString();

    Object rev = _in.readSexp();
    
    _in.expect(')');
    _in.expect(')');

    String type = "none";
    
    try {
      Node node = _session.getRootNode().getNode(_rootPath + path);

      if (node.isNodeType("nt:folder"))
	type = "dir";
      else if (node.isNodeType("nt:file"))
	type = "file";
    } catch (PathNotFoundException e) {
      log.log(Level.FINEST, e.toString(), e);
    } catch (Exception e) {
      log.log(Level.FINE, e.toString(), e);
    }

    println("( success ( ( ) 0: ) )");

    println("( success ( " + type + " ) )");
  }

  /**
   * Handle get-dir
   */
  private void doGetDir()
    throws IOException
  {
    _in.expect('(');

    String path = _in.readString();

    _in.expect('(');

    long version = _in.readLong();

    _in.expect(')');
    
    String arg1 = _in.readLiteral();
    String arg2 = _in.readLiteral();
    
    _in.expect(')');
    _in.expect(')');

    Node node = lookupNode(path);

    if (node == null) {
      String msg = L.l("{0} is an unknown path", path);
      
      println("( failure ( ( ) " + msg.length() + ":" + msg + " ) )");

      return;
    }
    
    println("( success ( ( ) 0: ) )");

    try {
      long dirVersion = 1;
      
      print("( success ( " + dirVersion + " ( ) ( ");

      NodeIterator iter = node.getNodes();
      while (iter.hasNext()) {
	Node child = iter.nextNode();

	String name = child.getName();
	String type = "none";

	if (child.isNodeType("nt:file"))
	  type = "file";
	else if (child.isNodeType("nt:folder"))
	  type = "dir";

	long length = 0;
	boolean v = false;
	long fileVersion = 1;
	long date = 0;
	String lastModified = QDate.formatGMT(date,
					      "%Y-%m-%dT%H:%M:%S.%sZ");
	String user = "ferg";

	print("( " + name.length() + ":" + name + " " +
	      type + " " + length + " " + v + " " + fileVersion +
	      " ( " + lastModified.length() + ":" + lastModified + " ) " +
	      " ( " + user.length() + ":" + user + " ) )");
      }
      println(" ) ) )");
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Handle update
   */
  private void doUpdate()
    throws IOException
  {
    Object args = _in.readSexp();

    _in.expect(')');

    // check ??
    
    println("( success ( ( ) 0: ) )");
  }

  /**
   * Handle set-path
   */
  private void doSetPath()
    throws IOException
  {
    Object args = _in.readSexp();

    _in.expect(')');

    System.out.println("set-path: " + args);

    // Any errors accumulate until the finish-report
  }

  /**
   * Handle finish-report
   */
  private void doFinishReport()
    throws IOException
  {
    Object args = _in.readSexp();

    _in.expect(')');

    System.out.println("finish-report: " + args);

    // check ??
    
    println("( success ( ( ) 0: ) )");

    // XXX: also need to store the report params
    // here use update only

    int version = 1;

    println("( target-rev ( " + version + " ) )");

    try {
      Node node = lookupNode("");

      if (node != null) {
	Count count = new Count();

	String rootId = "d" + count.newDir();

	println("( open-root ( ( " + version + " ) " + enc(rootId) + " ) )");
      
	writeDirEdit(node, "", rootId, count);
      
	println("( close-edit ( ) )");
      }
    } catch (Exception e) {
      e.printStackTrace();
      
      throw new RuntimeException(e);
    }
  }

  static class Count {
    private int _dirIndex;
    private int _fileIndex;

    int newDir()
    {
      return _dirIndex++;
    }

    int newFile()
    {
      return _fileIndex++;
    }
  }

  private void writeDirEdit(Node node,
			    String path,
			    String id,
			    Count count)
    throws Exception
  {
    String idEnc = enc(id);

    long nodeVersion = 1;
    long commitDate = CurrentTime.getCurrentTime();

    printChangeDirProp(id, "svn:entry:committed-rev", "" + nodeVersion);
    printChangeDirProp(id, "svn:entry:committed-date",
		       toDate(commitDate));
    printChangeDirProp(id, "svn:entry:last-author",
		       "ferg");
    printChangeDirProp(id, "snv:entry:uuid", _uuid);

    NodeIterator iter = node.getNodes();
    while (iter.hasNext()) {
      Node child = iter.nextNode();

      if (child.isNodeType("nt:folder")) {
	String childId = "d" + count.newDir();

	String subPath;
	if (path.length() == 0)
	  subPath = child.getName();
	else
	  subPath = path + "/" + child.getName();

	println("( add-dir ( " +
		enc(subPath) + " " + idEnc + " " + enc(childId) +
		" ( ) ) )");

	writeDirEdit(child, subPath, childId, count);
      }
      else if (child.isNodeType("nt:file")) {
	writeFileEdit(id, path, child, count);
      }
    }
    
    println("( close-dir ( " + idEnc + " ) )");
  }
  
  private void writeFileEdit(String parentId,
			     String parentPath,
			     Node node,
			     Count count)
    throws Exception
  {
    String id = "c" + count.newFile();

    String path;
    if (parentPath.length() == 0)
      path = node.getName();
    else
      path = parentPath + "/" + node.getName();

    println("( add-file ( " +
	    enc(path) + " " + enc(parentId) + " " + enc(id) +
	    " ( ) ) )");

    long nodeVersion = 1;
    long commitDate = CurrentTime.getCurrentTime();

    printChangeFileProp(id, "svn:entry:committed-rev", "" + nodeVersion);
    printChangeFileProp(id, "svn:entry:committed-date",
			toDate(commitDate));
    printChangeFileProp(id, "svn:entry:last-author", _author);
    printChangeFileProp(id, "snv:entry:uuid", _uuid);

    String text = node.getProperty("jcr:content/jcr:data").getString();
    String checksum = printTextDelta(id, text);

    println("( close-file ( " + enc(id) + " ( " + enc(checksum) + " ) ) )");
  }

  private String printTextDelta(String id, String text)
    throws IOException
  {
    println("( apply-textdelta ( " + enc(id) + " ( ) ) )");

    printTextdeltaChunk(id, "SVN\u0000");

    StringBuilder sb = new StringBuilder();
    addSvnDiffInt(sb, 0);
    addSvnDiffInt(sb, 0);
    addSvnDiffInt(sb, text.length());

    int instLength;
    if (0 < text.length() && text.length() < 63)
      instLength = 1;
    else
      instLength = 1 + svndiffIntLength(text.length());
    
    addSvnDiffInt(sb, instLength);
    addSvnDiffInt(sb, text.length());

    printTextdeltaChunk(id, sb.toString());

    sb.setLength(0);

    if (instLength == 1) {
      sb.append((char) (0x80 + text.length()));
    }
    else {
      sb.append((char) (0x80));
      addSvnDiffInt(sb, text.length());
    }

    printTextdeltaChunk(id, sb.toString());
    printTextdeltaChunk(id, text);
    
    println("( textdelta-end ( " + enc(id) + " ) )");
    
    return calculateChecksum(text);
  }

  private String calculateChecksum(String text)
  {
    try {
      MessageDigest md5 = MessageDigest.getInstance("MD5");

      for (int i = 0; i < text.length(); i++) {
	md5.update((byte) text.charAt(i));
      }

      byte []digest = md5.digest();

      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < digest.length; i++) {
	sb.append(toHexDigit(digest[i] >> 4));
	sb.append(toHexDigit(digest[i]));
      }

      return sb.toString();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  private char toHexDigit(int b)
  {
    b = b & 0xf;

    if (b < 10)
      return (char) (b + '0');
    else
      return (char) (b - 10 + 'a');
  }

  private int svndiffIntLength(long value)
  {
    long mask = 0x7f;
    int bytes = 1;
    
    while ((value & ~mask) != 0) {
      mask = (mask << 7) | 0x7f;
      bytes++;
    }

    return bytes;
  }
    
  private void addSvnDiffInt(StringBuilder sb, long length)
  {
    int bytes = svndiffIntLength(length);

    for (bytes-- ; bytes >= 0; bytes--) {
      int bits = (int) ((length >> (7 * bytes)) & 0x7f);
      if (bytes > 0)
	sb.append((char) (0x80 | bits));
      else
	sb.append((char) bits);
    }
  }
  
  private void printTextdeltaChunk(String id, String data)
    throws IOException
  {
    println("( textdelta-chunk ( " + id.length() + ":" + id + " " +
	    data.length() + ":" + data + " ) )");
  }

  private void printChangeDirProp(String id, String key, String value)
    throws IOException
  {
    println("( change-dir-prop ( " +
	    id.length() + ":" + id + " " +
	    key.length() + ":" + key + " ( " +
	    value.length() + ":" + value + " ) ) )");
  }

  private void printChangeFileProp(String id, String key, String value)
    throws IOException
  {
    println("( change-file-prop ( " +
	    id.length() + ":" + id + " " +
	    key.length() + ":" + key + " ( " +
	    value.length() + ":" + value + " ) ) )");
  }

  private String toDate(long date)
  {
    return QDate.formatGMT(date, "%Y-%m-%dT%H:%M:%S.%sZ");
  }

  private String enc(String str)
  {
    return str.length() + ":" + str;
  }

  /**
   * Handle failure
   */
  private void doFailure()
    throws IOException
  {
    Object args = _in.readSexp();

    _in.expect(')');

    System.out.println("failure: " + args);

    // check ??
    
    println("( success ( ( ) 0: ) )");
  }

  /**
   * Handle success
   */
  private void doSuccess()
    throws IOException
  {
    Object args = _in.readSexp();

    _in.expect(')');

    System.out.println("success: " + args);

    // check ??
    
    println("( success ( ( ) 0: ) )");
  }
  
  private Node lookupNode(String path)
  {
    if (_rootPath.length() == 0) {
    }
    else if (path.length() == 0) {
      path = _rootPath;
    }
    else if (! _rootPath.endsWith("/") && ! path.startsWith("/"))
      path = _rootPath + '/' + path;
    else
      path = _rootPath + path;

    try {
      Node node = _session.getRootNode().getNode(path);

      return node;
    } catch (PathNotFoundException e) {
      log.log(Level.FINEST, e.toString(), e);

      return null;
    } catch (RepositoryException e) {
      throw new RuntimeException(e);
    }
  }

  private void print(String s)
    throws IOException
  {
    if (log.isLoggable(Level.FINER))
      log.finer(s);
    
    _os.println(s);

    _os.flush();
  }

  /**
   * Skipts a s-exp
   */
  public void skipSexp()
    throws IOException
  {
    _in.readSexp();
  }

  private void println(String msg)
    throws IOException
  {
    if (log.isLoggable(Level.FINER))
      log.finer(msg);
    
    _os.println(msg);

    _os.flush();
  }

  private IOException error(String msg)
  {
    return new IOException(msg);
  }
  
  public boolean handleResume()
  {
    return false;
  }
  
  public void protocolCloseEvent()
  {
  }
}
