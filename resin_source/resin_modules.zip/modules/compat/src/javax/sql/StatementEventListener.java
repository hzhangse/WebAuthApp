package javax.sql;

public interface StatementEventListener {
}
