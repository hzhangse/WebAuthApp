package java.sql;

public interface NClob {
}
