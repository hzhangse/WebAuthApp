package java.sql;

public class SQLClientInfoException extends SQLException
{
}
